package com.andersoncarlosfs.execution;

import java.util.ArrayList;
import com.andersoncarlosfs.execution.parsers.ParseResultsForWS;
import com.andersoncarlosfs.execution.parsers.WebServiceDescription;
import com.andersoncarlosfs.execution.download.WebService;

public class Main {

    public static final void main(String[] args) throws Exception {
        //Testing with loading the description WS
        //WebService ws = WebServiceDescription.loadDescription("tmdb_getArtistInfoByName");
        //String fileWithCallResult = ws.getCallResult("Bruce Willis");

        WebService ws = null;

        String fileWithCallResult = null;
        String fileWithTransfResults = null;

        /**
         * mb_getArtistInfoByName
         */
        System.out.println("mb_getArtistInfoByName");

        ws = WebServiceDescription.loadDescription("mb_getArtistInfoByName");

        fileWithCallResult = ws.getCallResult("Frank Sinatra");

        System.out.println("The call is: " + fileWithCallResult);

        fileWithTransfResults = ws.getTransformationResult(fileWithCallResult);

        ArrayList<String[]> listOfTupleResult = ParseResultsForWS.showResults(fileWithTransfResults, ws);

        System.out.println("The tuple results are:");
        for (String[] tuple : listOfTupleResult) {
            System.out.print("(");
            for (int i = 0; i < tuple.length - 1; i++) {
                System.out.print(tuple[i] + ", ");
            }
            System.out.print(tuple[tuple.length - 1]);
            System.out.print(")");
            System.out.println();
        }

        System.out.println();

        /**
         * mb_getAlbumByArtist
         */
        System.out.println("mb_getAlbumByArtist");

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (String[] values : listOfTupleResult) {

                    String artistId = values[1];

                    WebService ws = WebServiceDescription.loadDescription("mb_getAlbumByArtistId");

                    String fileWithCallResult = ws.getCallResult(artistId);

                    System.out.println("The call is: " + fileWithCallResult);

                    try {
                        ws.getTransformationResult(fileWithCallResult);
                    } catch (Exception exception) {
                        System.out.println("Error in the call: " + fileWithCallResult);
                    }
                }
            }
        }).start();

        try {
            Thread.sleep(1);
        } catch (InterruptedException exception) {
            System.out.println("Error in the program");
        } finally {
            Thread.currentThread().interrupt();
        }

        for (String[] values : listOfTupleResult) {

            String artistId = values[1];

            try {
                Thread.sleep(1000);
            } catch (InterruptedException exception) {
                System.out.println("Error in the call: " + fileWithCallResult);
            } finally {
                Thread.currentThread().interrupt();
            }

            ws = WebServiceDescription.loadDescription("mb_getAlbumByArtistId");

            fileWithCallResult = ws.getCallResult(artistId);

            fileWithTransfResults = ws.getTransformationResult(fileWithCallResult);

            ArrayList<String[]> listOfTupleResult2 = ParseResultsForWS.showResults(fileWithTransfResults, ws);

            System.out.println("The tuple results are:");
            for (String[] tuple : listOfTupleResult2) {
                System.out.print("(");
                for (int i = 0; i < tuple.length - 1; i++) {
                    System.out.print(tuple[i] + ", ");
                }
                System.out.print(tuple[tuple.length - 1]);
                System.out.print(")");
                System.out.println();
            }

        }

    }

}
