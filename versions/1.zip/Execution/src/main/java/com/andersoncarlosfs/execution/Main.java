package com.andersoncarlosfs.execution;

import java.util.ArrayList;
import com.andersoncarlosfs.execution.parsers.ParseResultsForWS;
import com.andersoncarlosfs.execution.parsers.WebServiceDescription;
import com.andersoncarlosfs.execution.download.WebService;

public class Main {

    public static final void main(String[] args) throws Exception {
        //List<String> params = Arrays.asList("https://api.themoviedb.org/3/search/person?api_key=d335eef1e8e85b73cfa5f57cc3d50e4d&query=", null);

        //Testing with loading the description WS
        //WebService ws = WebServiceDescription.loadDescription("tmdb_getArtistInfoByName");
        WebService ws = WebServiceDescription.loadDescription("mb_getArtistInfoByName");

        //String fileWithCallResult = ws.getCallResult("Bruce Willis");
        String fileWithCallResult = ws.getCallResult("Leonard Cohen");

        System.out.println("The call is: " + fileWithCallResult);

        String fileWithTransfResults = ws.getTransformationResult(fileWithCallResult);

        ArrayList<String[]> listOfTupleResult = ParseResultsForWS.showResults(fileWithTransfResults, ws);

        System.out.println("The tuple results are:");
        for (String[] tuple : listOfTupleResult) {
            System.out.print("(");
            for (int i = 0; i < tuple.length - 1; i++) {
                System.out.print(tuple[i] + ", ");
            }
            System.out.print(tuple[tuple.length - 1]);
            System.out.print(")");
            System.out.println();
        }
    }

}
